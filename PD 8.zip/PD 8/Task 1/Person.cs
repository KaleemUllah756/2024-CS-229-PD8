﻿using System;

class Person
{
    public string Name { get; set; }

    public Person(string name)
    {
        Name = name;
    }

    public virtual string ToString()
    {
        return $"Person: {Name}";
    }
}