﻿class Student : Person
{
    public int RollNo { get; set; }

    public Student(string name, int rollNo) : base(name)
    {
        RollNo = rollNo;
    }

    public override string ToString()
    {
        return $"Student: {Name}, Roll No: {RollNo}";
    }
}