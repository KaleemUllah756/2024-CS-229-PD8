﻿using System;

class Program
{
    static void Main()
    {
        Person p = new Person("Ali");
        Student s = new Student("Sara", 101);
        Teacher t = new Teacher("Mr. Ahmed", "Math");

        Console.WriteLine(p.ToString());
        Console.WriteLine(s.ToString());
        Console.WriteLine(t.ToString());
    }
}
