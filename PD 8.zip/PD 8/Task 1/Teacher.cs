﻿class Teacher : Person
{
    public string Subject { get; set; }

    public Teacher(string name, string subject) : base(name)
    {
        Subject = subject;
    }

    public override string ToString()
    {
        return $"Teacher: {Name}, Subject: {Subject}";
    }
}

