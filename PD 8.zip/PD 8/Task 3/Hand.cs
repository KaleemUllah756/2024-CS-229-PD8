﻿using System.Collections.Generic;

public class Hand
{
    protected List<Card> cards;

    public Hand()
    {
        cards = new List<Card>();
    }

    public void AddCard(Card c)
    {
        if (c != null)
            cards.Add(c);
    }

    public void Clear()
    {
        cards.Clear();
    }

    public int GetCardCount()
    {
        return cards.Count;
    }

    public Card GetCard(int position)
    {
        if (position >= 0 && position < cards.Count)
            return cards[position];
        return null;
    }

    public void ShowHand()
    {
        foreach (Card card in cards)
            System.Console.WriteLine(card);
    }
}



