﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Welcome to Blackjack!\n");

        Deck deck = new Deck();
        BlackjackHand player = new BlackjackHand();
        BlackjackHand dealer = new BlackjackHand();

      
        player.AddCard(deck.DealCard());
        dealer.AddCard(deck.DealCard());
        player.AddCard(deck.DealCard());
        dealer.AddCard(deck.DealCard());

        Console.WriteLine("Your hand:");
        player.ShowHand();
        Console.WriteLine("Total: " + player.GetBlackjackValue());

        Console.WriteLine("\nDealer shows:");
        Console.WriteLine(dealer.GetCard(0)); 

        
        while (player.GetBlackjackValue() < 21)
        {
            Console.Write("\nDo you want to Hit (H) or Stand (S)? ");
            string choice = Console.ReadLine().ToUpper();

            if (choice == "H")
            {
                player.AddCard(deck.DealCard());
                Console.WriteLine("Your hand:");
                player.ShowHand();
                Console.WriteLine("Total: " + player.GetBlackjackValue());
            }
            else if (choice == "S")
            {
                break;
            }
        }

        int playerTotal = player.GetBlackjackValue();
        if (playerTotal > 21)
        {
            Console.WriteLine("\nYou BUSTED! Dealer wins.");
            return;
        }

       
        Console.WriteLine("\nDealer's hand:");
        dealer.ShowHand();
        Console.WriteLine("Total: " + dealer.GetBlackjackValue());

        while (dealer.GetBlackjackValue() < 17)
        {
            Console.WriteLine("Dealer hits...");
            dealer.AddCard(deck.DealCard());
            dealer.ShowHand();
            Console.WriteLine("Total: " + dealer.GetBlackjackValue());
        }

        int dealerTotal = dealer.GetBlackjackValue();

        Console.WriteLine("\nFinal Scores:");
        Console.WriteLine("Your total: " + playerTotal);
        Console.WriteLine("Dealer total: " + dealerTotal);

        if (dealerTotal > 21 || playerTotal > dealerTotal)
            Console.WriteLine("You WIN!");
        else if (playerTotal < dealerTotal)
            Console.WriteLine("Dealer WINS!");
        else
            Console.WriteLine("It's a TIE!");
    }
}

