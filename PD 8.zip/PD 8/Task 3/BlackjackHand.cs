﻿public class BlackjackHand : Hand
{
    public int GetBlackjackValue()
    {
        int val = 0;
        int aceCount = 0;

        foreach (Card card in cards)
        {
            int cardValue = card.GetValue();

            if (cardValue > 10)  
                val += 10;
            else if (cardValue == 1)
            {
                val += 11; 
                aceCount++;
            }
            else
                val += cardValue;
        }

      
        while (val > 21 && aceCount > 0)
        {
            val -= 10; 
            aceCount--;
        }

        return val;
    }
}

