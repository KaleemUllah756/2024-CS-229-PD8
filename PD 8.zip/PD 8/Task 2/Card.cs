﻿using System;
using System.Collections.Generic;

public class Card
{
    private int value;
    private int suit;

    public Card(int theValue, int theSuit)
    {
        value = theValue;
        suit = theSuit;
    }

    public int GetValue() => value;
    public int GetSuit() => suit;

    public string GetValueAsString()
    {
        if (value == 1) return "Ace";
        if (value == 11) return "Jack";
        if (value == 12) return "Queen";
        if (value == 13) return "King";
        return value.ToString();
    }

    public string GetSuitAsString()
    {
        return suit switch
        {
            1 => "Clubs",
            2 => "Diamonds",
            3 => "Spades",
            4 => "Hearts",
            _ => "Unknown"
        };
    }

    public override string ToString()
    {
        return $"{GetValueAsString()} of {GetSuitAsString()}";
    }
}

