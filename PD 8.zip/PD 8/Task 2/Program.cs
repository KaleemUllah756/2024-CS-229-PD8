﻿using System;

class Program
{
    static void Main()
    {
        int gamesPlayed = 0;
        int totalScore = 0;

        while (true)
        {
            Console.WriteLine("\nStarting a new game of HighLow...\n");
            Deck deck = new Deck();
            Card currentCard = deck.DealCard();
            int score = 0;

            while (deck.CardsLeft() > 0)
            {
                Console.WriteLine("Current card: " + currentCard);
                Console.Write("Will the next card be Higher (H) or Lower (L)? ");
                string guess = Console.ReadLine().ToUpper();

                Card nextCard = deck.DealCard();
                Console.WriteLine("Next card: " + nextCard);

                if ((guess == "H" && nextCard.GetValue() > currentCard.GetValue()) ||
                    (guess == "L" && nextCard.GetValue() < currentCard.GetValue()))
                {
                    Console.WriteLine("Correct guess!\n");
                    score++;
                    currentCard = nextCard;
                }
                else
                {
                    Console.WriteLine("Wrong guess! Game over.\n");
                    break;
                }
            }

            Console.WriteLine($"You scored {score} points.");
            gamesPlayed++;
            totalScore += score;

            Console.Write("Play again? (Y/N): ");
            if (Console.ReadLine().ToUpper() != "Y") break;
        }

        Console.WriteLine($"\nGames Played: {gamesPlayed}, Average Score: {(float)totalScore / gamesPlayed:F2}");
    }
}

