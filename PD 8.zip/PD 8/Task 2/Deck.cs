﻿using System;
using System.Collections.Generic;

public class Deck
{
    private List<Card> cards;
    private int currentCardIndex;

    public Deck()
    {
        cards = new List<Card>();
        for (int suit = 1; suit <= 4; suit++)
        {
            for (int value = 1; value <= 13; value++)
            {
                cards.Add(new Card(value, suit));
            }
        }
        Shuffle();
    }

    public void Shuffle()
    {
        Random rand = new Random();
        for (int i = 0; i < cards.Count; i++)
        {
            int j = rand.Next(cards.Count);
            (cards[i], cards[j]) = (cards[j], cards[i]);
        }
        currentCardIndex = 0;
    }

    public int CardsLeft() => cards.Count - currentCardIndex;

    public Card DealCard()
    {
        if (CardsLeft() == 0) return null;
        return cards[currentCardIndex++];
    }
}

